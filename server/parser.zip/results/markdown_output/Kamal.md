## Kamal
| Unnamed: 0 | Supplier Partner Performance Matrix | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 | Unnamed: 20 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| NaN | Tata AutoComp Business Unit: TM CHAKAN & CHINCHWAD | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: lokesh sir ( kamal tools& die) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | Buyer: Mr. Avinash vadhane sir / Akash sir | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | shrikrushna shinde (KTD) - 2025 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | Sr No | Parameters | NaN | NaN | Unit | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Responsible person | Remarks |
| NaN | NaN | NaN | NaN | NaN | NaN | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Average | NaN | NaN |
| Group 2 | 1 | Safety- Accident data | NaN | NaN | nos | NaN | 0 | 0 | 0 | 1 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | 2 | Production loss due to Material shortage | NaN | NaN | Hrs | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| NaN | 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % | NaN | 100 | 100 | 100 | 100 | 100 | NaN | NaN | NaN | NaN | NaN | NaN | 100 | NaN | NaN |
| NaN | 4 | Number of trips / month | NaN | NaN | nos | NaN | 18 | 18 | 21 | 38 | 27 | NaN | NaN | NaN | NaN | NaN | NaN | 24.4 | NaN | NaN |
| NaN | 5 | Qty Shipped / month | NaN | NaN | nos | NaN | 28481 | 25382 | 43416 | 74989 | 50865 | NaN | NaN | NaN | NaN | NaN | NaN | 44626.6 | NaN | NaN |
| NaN | 6 | No of Parts/ Trip | NaN | NaN | nos | NaN | 1582.277778 | 1410.111111 | 2067.428571 | 1973.394737 | 1883.888889 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | 7 | Vehicle turnaround time | NaN | NaN | Hrs | NaN | 4 | 1 | 1 | 1 | 2 | NaN | NaN | NaN | NaN | NaN | NaN | 1.8 | NaN | NaN |
| NaN | 8 | Machin break down Hrs | NaN | NaN | Hrs | NaN | 0 | 0 | 2 | 0 | 0 |  | NaN | NaN | NaN | NaN | NaN | 0.4 | NaN | NaN |
| NaN | 9 | No of Machines breakdown | NaN | NaN | nos | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| NaN | Notes: \n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | rej | NaN | 87 | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | rej | 87 | NaN | NaN | total production p | NaN | 32000 | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | total production p | 32000 | NaN | NaN | % | NaN | 100 | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| NaN | NaN | NaN | NaN | NaN | NaN | NaN | ppm | 10^5 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
