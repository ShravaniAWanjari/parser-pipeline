## Makarjyothi
| Supplier Partner Performance Matrix | Unnamed: 1 | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata AutoComp Business Unit: | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: Makarjyothi Polymers Pvt Ltd | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Buyer: Mr. Sachin Gadekar | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | SPOC: Mr. | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Sr No | Parameters | NaN | NaN | Unit | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Responsible person | Remarks |
| NaN | NaN | NaN | NaN | NaN | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Average | NaN | NaN |
| 1 | Safety- Accident data | NaN | NaN | nos | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| 2 | Production loss due to Material shortage | NaN | NaN | Hrs | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % | 100 | 100 | 100 | 100 | 100 | 100 | NaN | NaN | NaN | NaN | NaN | NaN | 100 | NaN | NaN |
| 4 | Number of trips / month | NaN | NaN | nos | 24 | 20 | 23 | 22 | 24 | 15 | NaN | NaN | NaN | NaN | NaN | NaN | 21.333333 | NaN | NaN |
| 5 | Qty Shipped / month | NaN | NaN | nos | 286520 | 324000 | 301200 | 302400 | 251000 | 249136 | NaN | NaN | NaN | NaN | NaN | NaN | 285709.333333 | NaN | NaN |
| 6 | No of Parts/ Trip | NaN | NaN | nos | 11938.333333 | 16200 | 13095.652174 | 13745.454545 | 10458.333333 | 16609.066667 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| 7 | Vehicle turnaround time | NaN | NaN | Hrs | 0.05 | 0.05 | 0.05 | 0.05 | 0.05 | 0.05 | NaN | NaN | NaN | NaN | NaN | NaN | 0.05 | NaN | NaN |
| 8 | Machin break down Hrs | NaN | NaN | Hrs | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| 9 | No of Machines breakdown | NaN | NaN | nos | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| Notes: \n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |