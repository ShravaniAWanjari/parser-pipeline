## Daxter
| Supplier Partner Performance Matrix | Unnamed: 1 | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata AutoComp Business Unit: Chinchwad 01 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: Daxter Polymers | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Buyer: Mr. Pawan Patil | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | SPOC: Mr. Pankaj Panda | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Sr No | Parameters | NaN | NaN | Unit | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Responsible person | Remarks |
| NaN | NaN | NaN | NaN | NaN | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Average | NaN | NaN |
| 1 | Safety- Accident data | NaN | NaN | nos | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Pankaj Panda | NaN |
| 2 | Production loss due to Material shortage at TACO | NaN | NaN | Hrs | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Pradeep Pore | NaN |
| 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % | NaN | 82 | 89 | 97 | 95.65 | 88 | NaN | NaN | NaN | NaN | NaN | NaN | 90.33 | Pankaj Kasara | NaN |
| 4 | Number of trips / month | NaN | NaN | nos | NaN | 75 | 69 | 48 | 49 | 51 | NaN | NaN | NaN | NaN | NaN | NaN | 58.4 | Pankaj Kasara | NaN |
| 5 | Qty Shipped / month | NaN | NaN | nos | NaN | 24369 | 24653 | 25638 | 30342 | 26383 | NaN | NaN | NaN | NaN | NaN | NaN | 26277 | Pankaj Kasara | NaN |
| 6 | No of Parts/ Trip | NaN | NaN | nos | NaN | 324.92 | 357.289855 | 534.125 | 619.22449 | 517.313725 | NaN | NaN | NaN | NaN | NaN | NaN | 470.574614 | Pankaj Kasara | NaN |
| 7 | Vehicle turnaround time\n(Daxter to TACO and Back) | NaN | NaN | Hrs | NaN | 6 | 6 | 6.16 | 6.4 | 6.8 | NaN | NaN | NaN | NaN | NaN | NaN | 6.272 | Pankaj Kasara | NaN |
| 8 | Machin break down Hrs | NaN | NaN | Hrs | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Anil Patil | NaN |
| 9 | No of Machines breakdown | NaN | NaN | nos | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Anil Patil | NaN |
| Notes: \n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
