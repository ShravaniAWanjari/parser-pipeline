## Shree Stamping
| Supplier Partner Performance Matrix | Unnamed: 1 | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata AutoComp Business Unit: | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Buyer: Mr. | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | SPOC: Mr. | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Sr No | Parameters | NaN | NaN | Frequency of rating (M / Q) | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Responsible person | Remarks |
| NaN | NaN | NaN | NaN | NaN | Jan-25 | Feb-25 | Mar-25 | Apr-25 | May-25 | Jun-25 | Jul-25 | Aug-25 | Sep-25 | Oct-25 | Nov-25 | Dec-25 | Average | NaN | NaN |
| 1 | Safety- Accident data | NaN | NaN | nos | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Shyam | NaN |
| 2 | Production loss due to Material shortage | NaN | NaN | Hrs | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Shyam | NaN |
| 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % | 59 | 100 | 100 | 31 | 7 | 21 | NaN | NaN | NaN | NaN | NaN | NaN | 0.5984 | Sagar | NaN |
| 4 | Number of trips / month | NaN | NaN | nos | 4 | 5 | 3 | 3 | 8 | 8 | NaN | NaN | NaN | NaN | NaN | NaN | 5.166667 | Ojha | NaN |
| 5 | Qty Shipped / month | NaN | NaN | nos | 1344 | 1680 | 1008 | 1208 | 2538 | 1956 | NaN | NaN | NaN | NaN | NaN | NaN | 1622.333333 | Ojha | NaN |
| 6 | No of Parts/ Trip | NaN | NaN | nos | 336 | 336 | 336 | 402.666667 | 317.25 | 244.5 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| 7 | Vehicle turnaround time | NaN | NaN | Hrs | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | NaN | NaN | NaN | NaN | NaN | NaN | 0.5 | Ojha | NaN |
| 8 | Machin break down Hrs | NaN | NaN | Hrs | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Shyam | Not Monitored |
| 9 | No of Machines breakdown | NaN | NaN | nos | 0 | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Shyam | Not Monitored |
| Notes: \n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
