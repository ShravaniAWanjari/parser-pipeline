## Acute Wiring
| Supplier Partner Performance Matrix | Unnamed: 1 | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata AutoComp Business Unit: TACO-AI/ TATA-FICOSA/ TACO-EV/ TACO-PRESTOLITE | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: Acute Harness Technologies | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Buyer: Mr. Manohar Datt | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | SPOC: Mr. Ganesh Kotwal | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Sr No | Parameters | NaN | NaN | Frequency of rating (M / Q) | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Responsible person | Remarks |
| NaN | NaN | NaN | NaN | NaN | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Average | NaN | NaN |
| 1 | Safety- Accident data | NaN | NaN | nos | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| 2 | Production loss due to Material shortage | NaN | NaN | Hrs | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % | NaN | 100 | 100 | 100 | 100 | 100 | NaN | NaN | NaN | NaN | NaN | NaN | 100 | NaN | NaN |
| 4 | Number of trips / month | NaN | NaN | nos | NaN | 2 | 7 | 9 | 12 | 23 | NaN | NaN | NaN | NaN | NaN | NaN | 10.6 | NaN | NaN |
| 5 | Qty Shipped / month | NaN | NaN | nos | NaN | 2000 | 1611 | 9688 | 9148 | 12091 | NaN | NaN | NaN | NaN | NaN | NaN | 6907.6 | NaN | NaN |
| 6 | No of Parts/ Trip | NaN | NaN | nos | NaN | 1000 | 230.142857 | 1076.444444 | 762.333333 | 525.695652 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| 7 | Vehicle turnaround time | NaN | NaN | Hrs | NaN | 1 | 1 | 1 | 1 | 1 | NaN | NaN | NaN | NaN | NaN | NaN | 1 | NaN | NaN |
| 8 | Machin break down Hrs | NaN | NaN | Hrs | NaN | 1 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0.2 | NaN | NaN |
| 9 | No of Machines breakdown | NaN | NaN | nos | NaN | 1 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0.2 | NaN | NaN |
| Notes: \n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
