## CAM
| Supplier Partner Performance Matrix | Unnamed: 1 | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 | Unnamed: 20 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata AutoComp Business Unit: CHAKAN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: CAM TOOLS INDUSTRIES PVT. LTD. | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Buyer: Mr. | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | SPOC: Mr. | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Sr No | Parameters | NaN | NaN | Unit | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |  | Responsible person | Remarks | NaN |
| NaN | NaN | NaN | NaN | NaN | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Average |  |  | NaN |
| 1 | Safety- Accident data | NaN | NaN | nos | NaN | 0 | 2 | 1 | 0 | 0 |  |  |  |  |  |  | 0.6 |  |  | NaN |
| 2 | Production loss due to Material shortage | NaN | NaN | Hrs |  | 0 | 0 | 0 | 0 | 0 |  |  |  |  |  |  | 0 |  |  | overall |
| 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % |  | 59 | 56 | 54 | 54 | 80 |  |  |  |  |  |  | 60.6 |  |  | NaN |
| 4 | Number of trips / month | NaN | NaN | nos |  | 26 | 23 | 25 | 20 | 19 |  |  |  |  |  |  | 22.6 |  |  | NaN |
| 5 | Qty Shipped / month | NaN | NaN | nos |  | 26749 | 18134 | 8796 | 13048 | 13899 |  |  |  |  |  |  | 16125.2 |  |  | NaN |
| 6 | No of Parts/ Trip | NaN | NaN | nos | NaN | 1028.807692 | 788.434783 | 351.84 | 652.4 | 731.526316 | NaN | NaN | NaN | NaN | NaN | NaN | 710.601758 |  |  | NaN |
| 7 | Vehicle turnaround time | NaN | NaN | Hrs |  | 0 | 1.5 | 1.26 | 1.265217 | 1.083333 |  |  |  |  |  |  | 1.02171 |  |  | NaN |
| 8 | Machin break down Hrs | NaN | NaN | Hrs |  | 0 | 0 | 0 | 3.5 | 1.5 |  |  |  |  |  |  | 1 |  |  | overall |
| 9 | No of Machines breakdown | NaN | NaN | nos |  | 0 | 0 | 0 | 2 | 1 |  |  |  |  |  |  | 0.6 |  |  | overall |
| Notes:\n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
