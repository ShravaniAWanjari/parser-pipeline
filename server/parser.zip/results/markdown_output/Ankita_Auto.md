## Ankita Auto
| Supplier Partner Performance Matrix | Unnamed: 1 | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata AutoComp Business Unit: Ranjangaon | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: Ankita Autocoters | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Buyer: Mr. Mahesh shirsagar | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | SPOC: Mr. Rohan Dhamale | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Sr No | Parameters | NaN | NaN | Unit | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Responsible person | Remarks |
| NaN | NaN | NaN | NaN | NaN | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Average | NaN | NaN |
| 1 | Safety- Accident data | NaN | NaN | nos | NaN | NaN | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Mr Rohan | NaN |
| 2 | Production loss due to Material shortage | NaN | NaN | Hrs | NaN | NaN | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | Mr kirti | NaN |
| 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % | NaN | NaN | 100 | 100 | 100 | 100 | NaN | NaN | NaN | NaN | NaN | NaN | 1 | Mr Hemant | NaN |
| 4 | Number of trips / month | NaN | NaN | nos | NaN | NaN | 25 | 32 | 42 | 25 | NaN | NaN | NaN | NaN | NaN | NaN | 33 | Mr Hemant | NaN |
| 5 | Qty Shipped / month | NaN | NaN | nos | NaN | NaN | 124746 | 110312 | 226738 | 91743 | NaN | NaN | NaN | NaN | NaN | NaN | 92359.2 | Mr Hemant | NaN |
| 6 | No of Parts/ Trip | NaN | NaN | nos | NaN | NaN | 4989.84 | 3447.25 | 5398.52381 | 3669.72 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Mr Hemant | NaN |
| 7 | Vehicle turnaround time | NaN | NaN | Hrs | NaN | NaN | 5 | 4 | 4 | 4 | NaN | NaN | NaN | NaN | NaN | NaN | 4.333333 | Mr Hemant | NaN |
| 8 | Machin break down Hrs | NaN | NaN | Hrs | NaN | NaN | 4 | 3 | 3.87 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 3.623333 | Mr kirti | NaN |
| 9 | No of Machines breakdown | NaN | NaN | nos | NaN | NaN | 0.5 | 0.2 | 0.16 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0.286667 | Mr kirti | NaN |
| Notes: \n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
