## S B Precision Springs
| Supplier Partner Performance Matrix | Unnamed: 1 | Unnamed: 2 | Unnamed: 3 | Unnamed: 4 | Unnamed: 5 | Unnamed: 6 | Unnamed: 7 | Unnamed: 8 | Unnamed: 9 | Unnamed: 10 | Unnamed: 11 | Unnamed: 12 | Unnamed: 13 | Unnamed: 14 | Unnamed: 15 | Unnamed: 16 | Unnamed: 17 | Unnamed: 18 | Unnamed: 19 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata AutoComp Business Unit: Tata Ficosa | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Name of Supplier Partner: S. B. Precision Springs | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Buyer: Mr. Rajesh Joshi | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | SPOC: Mr. Niranjan .B. Shinde | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| Sr No | Parameters | NaN | NaN | Frequency of rating (M / Q) | Rating | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | Responsible person | Remarks |
| NaN | NaN | NaN | NaN | NaN | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Average | NaN | NaN |
| 1 | Safety- Accident data | NaN | NaN | nos | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| 2 | Production loss due to Material shortage | NaN | NaN | Hrs | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| 3 | OK delivery cycles- as per delivery calculation sheet of ACMA (%) | NaN | NaN | % | NaN | 100 | 100 | 100 | 100 | 100 | NaN | NaN | NaN | NaN | NaN | NaN | 100 | NaN | NaN |
| 4 | Number of trips / month | NaN | NaN | nos | NaN | 10 | 8 | 13 | 9 | 8 | NaN | NaN | NaN | NaN | NaN | NaN | 9.6 | NaN | NaN |
| 5 | Qty Shipped / month | NaN | NaN | nos | NaN | 262250 | 243500 | 359192 | 225350 | 208800 | NaN | NaN | NaN | NaN | NaN | NaN | 259818.4 | NaN | NaN |
| 6 | No of Parts/ Trip | NaN | NaN | nos | NaN | 26225 | 30437.5 | 27630.153846 | 25038.888889 | 26100 | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
| 7 | Vehicle turnaround time | NaN | NaN | Hrs | NaN | 0.44 | 0.28 | 0.61 | 0.35 | 0.49 | NaN | NaN | NaN | NaN | NaN | NaN | 0.434 | NaN | NaN |
| 8 | Machin break down Hrs | NaN | NaN | Hrs | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| 9 | No of Machines breakdown | NaN | NaN | nos | NaN | 0 | 0 | 0 | 0 | 0 | NaN | NaN | NaN | NaN | NaN | NaN | 0 | NaN | NaN |
| Notes: \n1)\n2)\n3) | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN | NaN |
